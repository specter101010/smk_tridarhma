-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 25 Okt 2026 pada 08.01
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `umkm`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `blocks`
--

CREATE TABLE `blocks` (
  `id` int(11) NOT NULL,
  `label` varchar(20) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'kosong'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `blocks`
--

INSERT INTO `blocks` (`id`, `label`, `status`) VALUES
(1, 'A1', 'terisi'),
(2, 'A2', 'terisi'),
(3, 'A3', 'terisi'),
(4, 'A4', 'terisi'),
(5, 'A5', 'terisi'),
(6, 'A6', 'terisi'),
(7, 'B1', 'terisi'),
(8, 'B2', 'terisi'),
(9, 'B3', 'terisi'),
(10, 'B4', 'terisi'),
(11, 'B5', 'terisi'),
(12, 'B6', 'terisi'),
(13, 'C1', 'terisi'),
(14, 'C2', 'diajukan'),
(15, 'C3', 'diajukan'),
(16, 'C4', 'kosong'),
(17, 'C5', 'kosong'),
(18, 'C6', 'kosong'),
(19, 'D1', 'kosong'),
(20, 'D2', 'kosong'),
(21, 'D3', 'kosong'),
(22, 'D4', 'kosong'),
(23, 'D5', 'kosong'),
(24, 'D6', 'kosong');

-- --------------------------------------------------------

--
-- Struktur dari tabel `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `code` varchar(12) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `method` varchar(10) DEFAULT NULL,
  `proof` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `orders`
--

INSERT INTO `orders` (`id`, `code`, `name`, `phone`, `address`, `method`, `proof`, `created_at`) VALUES
(1, 'DM0001', 'Andi', '081234567825', 'Palembang', 'cod', NULL, '2026-10-15 06:45:19'),
(2, 'DM0002', 'Joko', '081234567831', 'Palembang', 'cod', NULL, '2026-10-23 06:45:20'),
(3, 'DM0003', 'Andi', '081234567845', 'Palembang', 'cod', NULL, '2026-10-15 06:45:20'),
(4, 'DM0004', 'Joko', '081234567894', 'Palembang', 'qris', NULL, '2026-10-12 06:45:20'),
(5, 'DM0005', 'Rafi', '081234567837', 'Palembang', 'cod', NULL, '2026-10-13 06:45:20'),
(6, 'DM0006', 'Joko', '081234567876', 'Palembang', 'transfer', NULL, '2026-10-24 06:45:20'),
(7, 'DM0007', 'Rina', '081234567891', 'Palembang', 'qris', NULL, '2026-10-20 06:45:20'),
(8, 'DM0008', 'Nadia', '081234567883', 'Palembang', 'transfer', NULL, '2026-10-19 06:45:20'),
(9, 'DM0009', 'Joko', '081234567873', 'Palembang', 'cod', NULL, '2026-10-25 06:45:20'),
(10, 'DM0010', 'Joko', '081234567859', 'Palembang', 'qris', NULL, '2026-10-18 06:45:20'),
(11, 'DM0011', 'Nadia', '081234567813', 'Palembang', 'cod', NULL, '2026-10-12 06:45:20'),
(12, 'DM0012', 'Andi', '081234567890', 'Palembang', 'cod', NULL, '2026-10-25 06:45:20'),
(13, 'DM0013', 'Nadia', '081234567814', 'Palembang', 'qris', NULL, '2026-10-15 06:45:20'),
(14, 'DM0014', 'Rafi', '081234567895', 'Palembang', 'qris', NULL, '2026-10-15 06:45:20'),
(15, 'DM0015', 'Rina', '081234567842', 'Palembang', 'qris', NULL, '2026-10-19 06:45:20'),
(16, 'DM0016', 'Nadia', '081234567857', 'Palembang', 'transfer', NULL, '2026-10-23 06:45:20'),
(17, 'DM0017', 'Andi', '081234567874', 'Palembang', 'cod', NULL, '2026-10-17 06:45:20'),
(18, 'DM0018', 'Nadia', '081234567867', 'Palembang', 'qris', NULL, '2026-10-13 06:45:20'),
(19, 'DM0019', 'Bima', '081234567874', 'Palembang', 'cod', NULL, '2026-10-16 06:45:20'),
(20, 'DM0020', 'Tika', '081234567819', 'Palembang', 'cod', NULL, '2026-10-13 06:45:20'),
(21, 'DM0021', 'Salsa', '081234567845', 'Palembang', 'qris', NULL, '2026-10-15 06:45:20'),
(22, 'DM0022', 'Tika', '081234567834', 'Palembang', 'cod', NULL, '2026-10-16 06:45:20'),
(23, 'DM0023', 'Joko', '081234567827', 'Palembang', 'cod', NULL, '2026-10-22 06:45:20'),
(24, 'DM0024', 'Andi', '081234567887', 'Palembang', 'transfer', NULL, '2026-10-23 06:45:20'),
(25, 'DM0025', 'Tika', '081234567861', 'Palembang', 'qris', NULL, '2026-10-13 06:45:20'),
(26, 'DM0026', 'Rina', '081234567873', 'Palembang', 'qris', NULL, '2026-10-17 06:45:20'),
(27, 'DM0027', 'Andi', '081234567896', 'Palembang', 'qris', NULL, '2026-10-22 06:45:20'),
(28, 'DM0028', 'Nadia', '081234567842', 'Palembang', 'cod', NULL, '2026-10-15 06:45:20'),
(29, 'DM0029', 'Andi', '081234567883', 'Palembang', 'cod', NULL, '2026-10-16 06:45:20'),
(30, 'DM0030', 'Nadia', '081234567899', 'Palembang', 'qris', NULL, '2026-10-13 06:45:20');

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `sub_order_id` int(11) DEFAULT NULL,
  `name` varchar(120) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `order_items`
--

INSERT INTO `order_items` (`id`, `sub_order_id`, `name`, `price`, `qty`) VALUES
(1, 1, 'Tempat Pensil Bambu', 25000, 2),
(2, 2, 'Dasi Batik', 40000, 1),
(3, 3, 'Miniatur Perahu', 120000, 1),
(4, 4, 'Tanjak Songket', 120000, 1),
(5, 5, 'Kue Nastar', 45000, 3),
(6, 6, 'Dompet Sachet', 30000, 2),
(7, 7, 'Wedang Rempah', 15000, 2),
(8, 8, 'Vas Rotan', 70000, 2),
(9, 9, 'Talenan Jati', 55000, 2),
(10, 10, 'Lampu Hias Botol', 65000, 1),
(11, 11, 'Gantungan Kunci Songket', 15000, 3),
(12, 12, 'Cheese Stick', 20000, 1),
(13, 13, 'Kemeja Batik', 135000, 3),
(14, 14, 'Gantungan Kunci Songket', 15000, 2),
(15, 15, 'Kemeja Batik', 135000, 2),
(16, 16, 'Teh Kayu Aro', 30000, 3),
(17, 17, 'Teh Kayu Aro', 30000, 1),
(18, 18, 'Stand HP Akrilik', 25000, 2),
(19, 19, 'Kopi Semendo 200g', 55000, 2),
(20, 20, 'Talenan Jati', 55000, 3),
(21, 21, 'Dasi Batik', 40000, 1),
(22, 22, 'Es Teh Botol', 8000, 2),
(23, 23, 'Tempat Pensil Bambu', 25000, 3),
(24, 24, 'Kue Nastar', 45000, 1),
(25, 25, 'Kopi Susu Botolan', 18000, 1),
(26, 26, 'Kue Nastar', 45000, 3),
(27, 27, 'Stand HP Akrilik', 25000, 2),
(28, 28, 'Vas Rotan', 70000, 3),
(29, 29, 'Kopi Bubuk Robusta', 40000, 2),
(30, 30, 'Ikat Pinggang Kulit', 95000, 1),
(31, 31, 'Vas Rotan', 70000, 1),
(32, 32, 'Keripik Pisang', 18000, 2),
(33, 33, 'Kemeja Batik', 135000, 2),
(34, 34, 'Kopi Semendo 200g', 55000, 1),
(35, 35, 'Sabun Herbal', 18000, 2),
(36, 36, 'Cheese Stick', 20000, 2),
(37, 37, 'Brownies Kukus', 35000, 3),
(38, 38, 'Sambal Roa', 35000, 3),
(39, 39, 'Kemeja Batik', 135000, 1),
(40, 40, 'Ikat Pinggang Kulit', 95000, 1),
(41, 41, 'Talenan Jati', 55000, 1),
(42, 42, 'Teh Kayu Aro', 30000, 2),
(43, 43, 'Topi Rajut', 45000, 1),
(44, 44, 'Kopi Susu Botolan', 18000, 2),
(45, 45, 'Dodol Garut', 28000, 1),
(46, 46, 'Teh Kayu Aro', 30000, 3),
(47, 47, 'Jus Jambu', 12000, 2),
(48, 48, 'Lampu Hias Botol', 65000, 1),
(49, 49, 'Gantungan Kunci Songket', 15000, 3),
(50, 50, 'Dompet Kulit', 60000, 3),
(51, 51, 'Talenan Jati', 55000, 3),
(52, 52, 'Sambal Roa', 35000, 3),
(53, 53, 'Jahe Instan', 20000, 1),
(54, 54, 'Ikat Pinggang Kulit', 95000, 3),
(55, 55, 'Ikat Pinggang Kulit', 95000, 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `stand_id` int(11) DEFAULT NULL,
  `name` varchar(120) DEFAULT NULL,
  `category` varchar(40) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `active` tinyint(4) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `products`
--

INSERT INTO `products` (`id`, `stand_id`, `name`, `category`, `price`, `stock`, `image`, `active`) VALUES
(1, 1, 'Tas Anyaman', 'Kriya', 85000, 20, 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=600&h=400&q=80', 1),
(2, 1, 'Dompet Kulit', 'Kriya', 60000, 15, 'https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=600&h=400&q=80', 1),
(3, 1, 'Tempat Pensil Bambu', 'Kriya', 25000, 40, 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=600&h=400&q=80', 1),
(4, 1, 'Vas Rotan', 'Kriya', 70000, 12, 'https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=600&h=400&q=80', 1),
(5, 2, 'Keripik Pisang', 'Makanan', 18000, 50, 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=600&h=400&q=80', 1),
(6, 2, 'Kue Nastar', 'Makanan', 45000, 30, 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&h=400&q=80', 1),
(7, 2, 'Sambal Roa', 'Makanan', 35000, 25, 'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?auto=format&fit=crop&w=600&h=400&q=80', 1),
(8, 2, 'Dodol Garut', 'Makanan', 28000, 35, 'https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=600&h=400&q=80', 1),
(9, 3, 'Kemeja Batik', 'Fashion', 135000, 18, 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=600&h=400&q=80', 1),
(10, 3, 'Kain Batik Tulis', 'Fashion', 220000, 10, 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&w=600&h=400&q=80', 1),
(11, 3, 'Masker Batik', 'Fashion', 15000, 60, 'https://images.unsplash.com/photo-1584634731339-252c581abfc5?auto=format&fit=crop&w=600&h=400&q=80', 1),
(12, 3, 'Dasi Batik', 'Fashion', 40000, 22, 'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=600&h=400&q=80', 1),
(13, 4, 'Kopi Semendo 200g', 'Makanan', 55000, 40, 'https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&w=600&h=400&q=80', 1),
(14, 4, 'Kopi Bubuk Robusta', 'Makanan', 40000, 50, 'https://images.unsplash.com/photo-1445116572660-236099ec97a0?auto=format&fit=crop&w=600&h=400&q=80', 1),
(15, 4, 'Teh Kayu Aro', 'Makanan', 30000, 45, 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=600&h=400&q=80', 1),
(16, 4, 'Gula Aren', 'Makanan', 25000, 60, 'https://images.unsplash.com/photo-1581441363689-1f3c3c414635?auto=format&fit=crop&w=600&h=400&q=80', 1),
(17, 5, 'Selendang Songket', 'Fashion', 350000, 8, 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&w=600&h=400&q=80', 1),
(18, 5, 'Tanjak Songket', 'Fashion', 120000, 12, 'https://images.unsplash.com/photo-1521369909029-2afed882baee?auto=format&fit=crop&w=600&h=400&q=80', 1),
(19, 5, 'Dompet Songket', 'Fashion', 65000, 20, 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=600&h=400&q=80', 1),
(20, 5, 'Gantungan Kunci Songket', 'Fashion', 15000, 80, 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=600&h=400&q=80', 1),
(21, 6, 'Madu Hutan', 'Lainnya', 45000, 30, 'https://images.unsplash.com/photo-1587049352851-8d4e89133924?auto=format&fit=crop&w=600&h=400&q=80', 1),
(22, 6, 'Jahe Instan', 'Lainnya', 20000, 50, 'https://img.lazcdn.com/g/p/d35726cb834287bd67662514f2b94ec9.jpg_720x720q80.jpg', 1),
(23, 6, 'Minyak Kelapa Murni', 'Lainnya', 38000, 25, 'https://images.unsplash.com/photo-1546554137-f86b9593a222?auto=format&fit=crop&w=600&h=400&q=80', 1),
(24, 6, 'Sabun Herbal', 'Lainnya', 18000, 70, 'https://images.unsplash.com/photo-1600857544200-b2f666a9a2ec?auto=format&fit=crop&w=600&h=400&q=80', 1),
(25, 7, 'Talenan Jati', 'Kriya', 55000, 25, 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=600&h=400&q=80', 1),
(26, 7, 'Jam Dinding Kayu', 'Kriya', 90000, 14, 'https://images.unsplash.com/photo-1563861826100-9cb868fdbe1c?auto=format&fit=crop&w=600&h=400&q=80', 1),
(27, 7, 'Rak Mini', 'Kriya', 75000, 16, 'https://images.unsplash.com/photo-1594620302200-9a762244a156?auto=format&fit=crop&w=600&h=400&q=80', 1),
(28, 7, 'Miniatur Perahu', 'Kriya', 120000, 9, 'https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=600&h=400&q=80', 1),
(29, 8, 'Brownies Kukus', 'Makanan', 35000, 30, 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=600&h=400&q=80', 1),
(30, 8, 'Pempek Frozen', 'Makanan', 40000, 40, 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&h=400&q=80', 1),
(31, 8, 'Kemplang Panggang', 'Makanan', 22000, 50, 'https://images.unsplash.com/photo-1621939514649-280e2aa2f2c3?auto=format&fit=crop&w=600&h=400&q=80', 1),
(32, 8, 'Cheese Stick', 'Makanan', 20000, 45, 'https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d?auto=format&fit=crop&w=600&h=400&q=80', 1),
(33, 9, 'Tas Daur Ulang', 'Kriya', 50000, 20, 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=600&h=400&q=80', 1),
(34, 9, 'Pot Botol Bekas', 'Kriya', 20000, 40, 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=600&h=400&q=80', 1),
(35, 9, 'Lampu Hias Botol', 'Kriya', 65000, 15, 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=600&h=400&q=80', 1),
(36, 9, 'Dompet Sachet', 'Kriya', 30000, 35, 'https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=600&h=400&q=80', 1),
(37, 10, 'Syal Rajut', 'Fashion', 60000, 25, 'https://images.unsplash.com/photo-1457545195570-67f207084966?auto=format&fit=crop&w=600&h=400&q=80', 1),
(38, 10, 'Topi Rajut', 'Fashion', 45000, 30, 'https://images.unsplash.com/photo-1576871337622-98d48d1cf531?auto=format&fit=crop&w=600&h=400&q=80', 1),
(39, 10, 'Tas Rajut', 'Fashion', 80000, 18, 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=600&h=400&q=80', 1),
(40, 10, 'Boneka Rajut', 'Fashion', 55000, 20, 'https://images.unsplash.com/photo-1559454403-b8fb88521f11?auto=format&fit=crop&w=600&h=400&q=80', 1),
(41, 11, 'Casing HP Custom', 'Lainnya', 35000, 50, 'https://images.unsplash.com/photo-1601593346740-925612772716?auto=format&fit=crop&w=600&h=400&q=80', 1),
(42, 11, 'Stand HP Akrilik', 'Lainnya', 25000, 60, 'https://images.unsplash.com/photo-1512499617640-c74ae3a79d37?auto=format&fit=crop&w=600&h=400&q=80', 1),
(43, 11, 'Lampu Meja LED', 'Lainnya', 85000, 20, 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=600&h=400&q=80', 1),
(44, 11, 'Kabel Charger', 'Lainnya', 30000, 70, 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&w=600&h=400&q=80', 1),
(45, 12, 'Es Teh Botol', 'Makanan', 8000, 100, 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=600&h=400&q=80', 1),
(46, 12, 'Jus Jambu', 'Makanan', 12000, 60, 'https://images.unsplash.com/photo-1613478223719-2ab802602423?auto=format&fit=crop&w=600&h=400&q=80', 1),
(47, 12, 'Wedang Rempah', 'Makanan', 15000, 40, 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=600&h=400&q=80', 1),
(48, 12, 'Kopi Susu Botolan', 'Makanan', 18000, 80, 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=600&h=400&q=80', 1),
(49, 13, 'Ikat Pinggang Kulit', 'Fashion', 95000, 15, 'https://images.unsplash.com/photo-1624222247344-550fb8f7b6c7?auto=format&fit=crop&w=600&h=400&q=80', 1),
(50, 13, 'Gelang Kulit', 'Fashion', 25000, 60, 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?auto=format&fit=crop&w=600&h=400&q=80', 1),
(51, 13, 'Tas Selempang', 'Fashion', 150000, 10, 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=600&h=400&q=80', 1),
(52, 13, 'Gantungan Kunci Kulit', 'Fashion', 12000, 100, 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=600&h=400&q=80', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `stands`
--

CREATE TABLE `stands` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `block_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `fee_fixed` int(11) DEFAULT 0,
  `fee_percent` decimal(4,1) DEFAULT 0.0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `stands`
--

INSERT INTO `stands` (`id`, `user_id`, `block_id`, `name`, `description`, `status`, `fee_fixed`, `fee_percent`) VALUES
(1, 2, 1, 'Kriya Nusantara', 'Kerajinan tangan karya siswa SMK', 'approved', 50000, 2.0),
(2, 3, 2, 'Dapur Nusantara', 'Camilan dan oleh-oleh khas daerah', 'approved', 50000, 2.5),
(3, 4, 3, 'Batik Muda', 'Batik modern untuk anak muda', 'approved', 50000, 3.0),
(4, 5, 4, 'Kopi Sumsel', 'Kopi dan teh pilihan petani lokal', 'approved', 50000, 5.0),
(5, 6, 5, 'Songket Palembang', 'Tenun songket khas Palembang', 'approved', 50000, 2.0),
(6, 7, 6, 'Herbal Sehat', 'Produk herbal dan perawatan alami', 'approved', 50000, 2.5),
(7, 8, 7, 'Kayu Kreatif', 'Furnitur mini dan dekorasi kayu', 'approved', 50000, 3.0),
(8, 9, 8, 'Cookies by Putri', 'Kue dan camilan buatan sendiri', 'approved', 50000, 5.0),
(9, 10, 9, 'Daur Ulang Kreasi', 'Kreasi dari barang bekas', 'approved', 50000, 2.0),
(10, 11, 10, 'Rajut Cantik', 'Rajutan tangan hangat dan unik', 'approved', 50000, 2.5),
(11, 12, 11, 'Gadget Corner SMK', 'Aksesoris gadget karya jurusan teknik', 'approved', 50000, 3.0),
(12, 13, 12, 'Aneka Minuman', 'Minuman segar dan jamu kekinian', 'approved', 50000, 5.0),
(13, 14, 13, 'Aksesoris Kulit', 'Aksesori kulit buatan tangan', 'approved', 50000, 2.0),
(14, 8, 14, 'Kayu Kreatif Outlet', 'Cabang kedua, menunggu persetujuan', 'pending', 0, 0.0),
(15, 12, 15, 'Gadget Corner Kampus', 'Stand kedua aksesoris gadget', 'pending', 0, 0.0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `sub_orders`
--

CREATE TABLE `sub_orders` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `stand_id` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `sub_orders`
--

INSERT INTO `sub_orders` (`id`, `order_id`, `stand_id`, `total`, `status`) VALUES
(1, 1, 1, 50000, 'ditolak'),
(2, 1, 3, 40000, 'menunggu_konfirmasi'),
(3, 1, 7, 120000, 'selesai'),
(4, 2, 5, 120000, 'diproses'),
(5, 3, 2, 135000, 'ditolak'),
(6, 3, 9, 60000, 'dikonfirmasi'),
(7, 3, 12, 30000, 'selesai'),
(8, 4, 1, 140000, 'dikonfirmasi'),
(9, 4, 7, 110000, 'selesai'),
(10, 4, 9, 65000, 'menunggu_konfirmasi'),
(11, 5, 5, 45000, 'selesai'),
(12, 6, 8, 20000, 'selesai'),
(13, 7, 3, 405000, 'menunggu_konfirmasi'),
(14, 8, 5, 30000, 'menunggu_konfirmasi'),
(15, 9, 3, 270000, 'selesai'),
(16, 9, 4, 90000, 'selesai'),
(17, 10, 4, 30000, 'diproses'),
(18, 11, 11, 50000, 'dikonfirmasi'),
(19, 12, 4, 110000, 'dikonfirmasi'),
(20, 12, 7, 165000, 'selesai'),
(21, 13, 3, 40000, 'menunggu_konfirmasi'),
(22, 13, 12, 16000, 'menunggu_konfirmasi'),
(23, 14, 1, 75000, 'menunggu_konfirmasi'),
(24, 14, 2, 45000, 'menunggu_konfirmasi'),
(25, 14, 12, 18000, 'selesai'),
(26, 15, 2, 135000, 'diproses'),
(27, 15, 11, 50000, 'dikonfirmasi'),
(28, 16, 1, 210000, 'dikonfirmasi'),
(29, 17, 4, 80000, 'selesai'),
(30, 17, 13, 95000, 'menunggu_konfirmasi'),
(31, 18, 1, 70000, 'menunggu_konfirmasi'),
(32, 18, 2, 36000, 'ditolak'),
(33, 19, 3, 270000, 'menunggu_konfirmasi'),
(34, 19, 4, 55000, 'ditolak'),
(35, 19, 6, 36000, 'selesai'),
(36, 20, 8, 40000, 'diproses'),
(37, 21, 8, 105000, 'dikonfirmasi'),
(38, 22, 2, 105000, 'menunggu_konfirmasi'),
(39, 22, 3, 135000, 'selesai'),
(40, 22, 13, 95000, 'dikonfirmasi'),
(41, 23, 7, 55000, 'menunggu_konfirmasi'),
(42, 24, 4, 60000, 'menunggu_konfirmasi'),
(43, 24, 10, 45000, 'selesai'),
(44, 24, 12, 36000, 'selesai'),
(45, 25, 2, 28000, 'selesai'),
(46, 25, 4, 90000, 'selesai'),
(47, 25, 12, 24000, 'dikonfirmasi'),
(48, 26, 9, 65000, 'menunggu_konfirmasi'),
(49, 27, 5, 45000, 'selesai'),
(50, 28, 1, 180000, 'diproses'),
(51, 28, 7, 165000, 'ditolak'),
(52, 29, 2, 105000, 'menunggu_konfirmasi'),
(53, 29, 6, 20000, 'selesai'),
(54, 29, 13, 285000, 'selesai'),
(55, 30, 13, 190000, 'selesai');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `role` enum('admin','seller') DEFAULT 'seller',
  `status` varchar(20) DEFAULT 'pending',
  `reason` varchar(255) DEFAULT NULL,
  `doc` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `status`, `reason`, `doc`) VALUES
(1, 'Admin Lapak', 'admin@umkm.test', '$2a$10$5vOe5I2IhB.xVxV5fol.gOB2Q6Ihj03gaCJ171koXsTj/uyAfvGAS', 'admin', 'approved', NULL, NULL),
(2, 'Budi Santoso', 'seller01@umkm.test', '$2a$10$F2w59ui39KfROt98xFMg0eBco6z/dZ19uvL4FDzVJUh2PEGD9tyRe', 'seller', 'approved', NULL, 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&h=400&q=80'),
(3, 'Siti Aminah', 'seller02@umkm.test', '$2a$10$F2w59ui39KfROt98xFMg0eBco6z/dZ19uvL4FDzVJUh2PEGD9tyRe', 'seller', 'approved', NULL, 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&h=400&q=80'),
(4, 'Rizky Pratama', 'seller03@umkm.test', '$2a$10$F2w59ui39KfROt98xFMg0eBco6z/dZ19uvL4FDzVJUh2PEGD9tyRe', 'seller', 'approved', NULL, 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&h=400&q=80'),
(5, 'Dewi Lestari', 'seller04@umkm.test', '$2a$10$F2w59ui39KfROt98xFMg0eBco6z/dZ19uvL4FDzVJUh2PEGD9tyRe', 'seller', 'approved', NULL, 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&h=400&q=80'),
(6, 'Ahmad Fauzi', 'seller05@umkm.test', '$2a$10$F2w59ui39KfROt98xFMg0eBco6z/dZ19uvL4FDzVJUh2PEGD9tyRe', 'seller', 'approved', NULL, 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&h=400&q=80'),
(7, 'Nur Aisyah', 'seller06@umkm.test', '$2a$10$F2w59ui39KfROt98xFMg0eBco6z/dZ19uvL4FDzVJUh2PEGD9tyRe', 'seller', 'approved', NULL, 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&h=400&q=80'),
(8, 'Dimas Wijaya', 'seller07@umkm.test', '$2a$10$F2w59ui39KfROt98xFMg0eBco6z/dZ19uvL4FDzVJUh2PEGD9tyRe', 'seller', 'approved', NULL, 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&h=400&q=80'),
(9, 'Putri Ayu', 'seller08@umkm.test', '$2a$10$F2w59ui39KfROt98xFMg0eBco6z/dZ19uvL4FDzVJUh2PEGD9tyRe', 'seller', 'approved', NULL, 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&h=400&q=80'),
(10, 'Fajar Nugroho', 'seller09@umkm.test', '$2a$10$F2w59ui39KfROt98xFMg0eBco6z/dZ19uvL4FDzVJUh2PEGD9tyRe', 'seller', 'approved', NULL, 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&h=400&q=80'),
(11, 'Maya Sari', 'seller10@umkm.test', '$2a$10$F2w59ui39KfROt98xFMg0eBco6z/dZ19uvL4FDzVJUh2PEGD9tyRe', 'seller', 'approved', NULL, 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&h=400&q=80'),
(12, 'Rangga Saputra', 'seller11@umkm.test', '$2a$10$F2w59ui39KfROt98xFMg0eBco6z/dZ19uvL4FDzVJUh2PEGD9tyRe', 'seller', 'approved', NULL, 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&h=400&q=80'),
(13, 'Lestari Handayani', 'seller12@umkm.test', '$2a$10$F2w59ui39KfROt98xFMg0eBco6z/dZ19uvL4FDzVJUh2PEGD9tyRe', 'seller', 'approved', NULL, 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&h=400&q=80'),
(14, 'Bagas Prakoso', 'seller13@umkm.test', '$2a$10$F2w59ui39KfROt98xFMg0eBco6z/dZ19uvL4FDzVJUh2PEGD9tyRe', 'seller', 'approved', NULL, 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&h=400&q=80'),
(15, 'Tono Hartono', 'seller14@umkm.test', '$2a$10$F2w59ui39KfROt98xFMg0eBco6z/dZ19uvL4FDzVJUh2PEGD9tyRe', 'seller', 'pending', NULL, 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&h=400&q=80'),
(16, 'Wulan Dari', 'seller15@umkm.test', '$2a$10$F2w59ui39KfROt98xFMg0eBco6z/dZ19uvL4FDzVJUh2PEGD9tyRe', 'seller', 'pending', NULL, 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=600&h=400&q=80');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `blocks`
--
ALTER TABLE `blocks`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indeks untuk tabel `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sub_order_id` (`sub_order_id`);

--
-- Indeks untuk tabel `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `stand_id` (`stand_id`);

--
-- Indeks untuk tabel `stands`
--
ALTER TABLE `stands`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `sub_orders`
--
ALTER TABLE `sub_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `stand_id` (`stand_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `blocks`
--
ALTER TABLE `blocks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT untuk tabel `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT untuk tabel `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT untuk tabel `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT untuk tabel `stands`
--
ALTER TABLE `stands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `sub_orders`
--
ALTER TABLE `sub_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`sub_order_id`) REFERENCES `sub_orders` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`stand_id`) REFERENCES `stands` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `stands`
--
ALTER TABLE `stands`
  ADD CONSTRAINT `stands_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `sub_orders`
--
ALTER TABLE `sub_orders`
  ADD CONSTRAINT `sub_orders_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sub_orders_ibfk_2` FOREIGN KEY (`stand_id`) REFERENCES `stands` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
